package com.zj198.model;

/**
 * KnwType entity. @author MyEclipse Persistence Tools
 */

public class KnwType implements java.io.Serializable {

	// Fields

	private static final long serialVersionUID = -940722488919855702L;
	private Integer id;
	private String name;
	
	// Constructors

	/** default constructor */
	public KnwType() {
	}

	/** minimal constructor */
	public KnwType(String name) {
		this.name = name;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
}