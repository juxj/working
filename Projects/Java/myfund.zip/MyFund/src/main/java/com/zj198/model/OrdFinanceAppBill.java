package com.zj198.model;

import java.util.Date;



/**
 * OrdFinanceAppBill entity. @author MyEclipse Persistence Tools
 */

public class OrdFinanceAppBill implements java.io.Serializable {

	private static final long serialVersionUID = 9053068124221381972L;
	private Integer id;
	private Integer appLoanId;
	private Integer blockNum;
	private Double capitalMustPay;
	private Double interestMustPay;
	private Date endPayDate;
	private Double paymentAmount;
	private Date paymentDt;

	/** default constructor */
	public OrdFinanceAppBill() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAppLoanId() {
		return this.appLoanId;
	}

	public void setAppLoanId(Integer appLoanId) {
		this.appLoanId = appLoanId;
	}

	public Integer getBlockNum() {
		return this.blockNum;
	}

	public void setBlockNum(Integer blockNum) {
		this.blockNum = blockNum;
	}

	public Double getCapitalMustPay() {
		return this.capitalMustPay;
	}

	public void setCapitalMustPay(Double capitalMustPay) {
		this.capitalMustPay = capitalMustPay;
	}

	public Double getInterestMustPay() {
		return this.interestMustPay;
	}

	public void setInterestMustPay(Double interestMustPay) {
		this.interestMustPay = interestMustPay;
	}

	public Date getEndPayDate() {
		return this.endPayDate;
	}

	public void setEndPayDate(Date endPayDate) {
		this.endPayDate = endPayDate;
	}

	public Double getPaymentAmount() {
		return this.paymentAmount;
	}

	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public Date getPaymentDt() {
		return this.paymentDt;
	}

	public void setPaymentDt(Date paymentDt) {
		this.paymentDt = paymentDt;
	}

}