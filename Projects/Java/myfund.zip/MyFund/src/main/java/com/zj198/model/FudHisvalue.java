package com.zj198.model;

import java.util.Date;

/**
 * FudHisvalue entity. @author MyEclipse Persistence Tools
 */

public class FudHisvalue implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7339916834263995939L;
	// Fields
	private Integer id;
	private String fundcode;
	private String levelcode;
	private Double unitvalue;
	private Double accumulatvalue;
	private Double dayincrease;
	private Double totalvalue;
	private Date day;

	// Constructors

	/** default constructor */
	public FudHisvalue() {
	}

	/** minimal constructor */
	public FudHisvalue(String fundcode, String levelcode) {
		this.fundcode = fundcode;
		this.levelcode = levelcode;
	}

	/** full constructor */
	public FudHisvalue(String fundcode, String levelcode, Double unitvalue,
			Double accumulatvalue, Double dayincrease, Double totalvalue,
			Date day) {
		this.fundcode = fundcode;
		this.levelcode = levelcode;
		this.unitvalue = unitvalue;
		this.accumulatvalue = accumulatvalue;
		this.dayincrease = dayincrease;
		this.totalvalue = totalvalue;
		this.day = day;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFundcode() {
		return this.fundcode;
	}

	public void setFundcode(String fundcode) {
		this.fundcode = fundcode;
	}

	public String getLevelcode() {
		return this.levelcode;
	}

	public void setLevelcode(String levelcode) {
		this.levelcode = levelcode;
	}

	public Double getUnitvalue() {
		return this.unitvalue;
	}

	public void setUnitvalue(Double unitvalue) {
		this.unitvalue = unitvalue;
	}

	public Double getAccumulatvalue() {
		return this.accumulatvalue;
	}

	public void setAccumulatvalue(Double accumulatvalue) {
		this.accumulatvalue = accumulatvalue;
	}

	public Double getDayincrease() {
		return this.dayincrease;
	}

	public void setDayincrease(Double dayincrease) {
		this.dayincrease = dayincrease;
	}

	public Double getTotalvalue() {
		return this.totalvalue;
	}

	public void setTotalvalue(Double totalvalue) {
		this.totalvalue = totalvalue;
	}

	public Date getDay() {
		return this.day;
	}

	public void setDay(Date day) {
		this.day = day;
	}

}