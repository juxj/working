package com.zj198.util;

public class InterestBean {
	private Integer stdt;
	private Integer enddt;
	private Double rate;
	public InterestBean(){
		
	}
	public InterestBean(Integer stdt, Integer enddt, Double rate){
		this.stdt = stdt;
		this.enddt = enddt;
		this.rate = rate;
	}
	public Integer getStdt() {
		return stdt;
	}
	public void setStdt(Integer stdt) {
		this.stdt = stdt;
	}
	public Integer getEnddt() {
		return enddt;
	}
	public void setEnddt(Integer enddt) {
		this.enddt = enddt;
	}
	public Double getRate() {
		return rate;
	}
	public void setRate(Double rate) {
		this.rate = rate;
	}
}
