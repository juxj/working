package com.zj198.model;

/**
 * DicCommon entity. @author MyEclipse Persistence Tools
 */

public class DicCommon implements java.io.Serializable {

	private static final long serialVersionUID = 1739400679836696937L;
	private Integer id;
	private String name;
	private Integer group;

	/** default constructor */
	public DicCommon() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getGroup() {
		return this.group;
	}

	public void setGroup(Integer group) {
		this.group = group;
	}

}