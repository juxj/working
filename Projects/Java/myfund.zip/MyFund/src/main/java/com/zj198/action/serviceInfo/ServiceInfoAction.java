package com.zj198.action.serviceInfo;

import com.opensymphony.xwork2.Action;
import com.zj198.action.BaseAction;

public class ServiceInfoAction extends BaseAction  implements Action{
	
	@Override
	public String execute() throws Exception {
		return null;
	}
}
