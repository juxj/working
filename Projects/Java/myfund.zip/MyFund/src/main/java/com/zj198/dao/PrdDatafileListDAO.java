package com.zj198.dao;

import com.zj198.model.PrdDatafileList;

/**
 * @author 岳龙
 * Description:
 * CreateAuthor:岳龙
 * CreateDate:2012-7-05 14:54:57
 */
public interface PrdDatafileListDAO extends BaseDAO<PrdDatafileList, Integer>{

}
