package com.zj198.model;

import java.util.Date;

/**
 * AdmUser entity. @author MyEclipse Persistence Tools
 */

public class AdmUser implements java.io.Serializable {

	private static final long serialVersionUID = -6537081284452333172L;
	private Integer id;
	private String username;
	private String password;
	private String realname;
	private String mobile;
	private String telephone;
	private Date createdt;
	private Date updatedt;
	private Short status;
	private Long rights;
	

	/** default constructor */
	public AdmUser() {
	}
	
	//simple admUser for keep in session
	public AdmUser(Integer id, String realname,Short status,Long rights){
		this.id = id;
		this.realname = realname;
		this.status = status;
		this.rights = rights;
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRealname() {
		return this.realname;
	}

	public void setRealname(String realname) {
		this.realname = realname;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public Date getCreatedt() {
		return this.createdt;
	}

	public void setCreatedt(Date createdt) {
		this.createdt = createdt;
	}

	public Date getUpdatedt() {
		return this.updatedt;
	}

	public void setUpdatedt(Date updatedt) {
		this.updatedt = updatedt;
	}

	public Short getStatus() {
		return this.status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Long getRights() {
		return rights;
	}

	public void setRights(Long rights) {
		this.rights = rights;
	}

}