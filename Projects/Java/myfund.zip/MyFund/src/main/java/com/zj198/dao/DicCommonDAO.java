package com.zj198.dao;

import java.util.List;

import com.zj198.model.DicCommon;

public interface DicCommonDAO extends BaseDAO<DicCommon, Integer> {
	public List<DicCommon> findByGroupId(int groupid);
	public List<DicCommon> findByIds(String ids) ;
}
