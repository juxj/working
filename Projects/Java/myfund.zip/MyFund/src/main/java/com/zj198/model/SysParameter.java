package com.zj198.model;

/**
 * SysParameter entity. @author MyEclipse Persistence Tools
 */

public class SysParameter implements java.io.Serializable {

	private static final long serialVersionUID = -2182319913362664164L;
	private Integer id;
	private Integer group;
	private String name;
	private String value;
	private String remarks;

	/** default constructor */
	public SysParameter() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getGroup() {
		return this.group;
	}

	public void setGroup(Integer group) {
		this.group = group;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}