package com.zj198.model;


import java.util.Date;

/**
 * KnwTitle entity. @author MyEclipse Persistence Tools
 */

public class KnwTitle implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 8933409484429960195L;
	/**
	 * 
	 */
	private Integer id;
	private Integer typeId;
	private String typeName;
	private String title;
	private String url;
	private String author;
	private String source;
	private Date issuedDate;
	private Short isAuthenticated;
	private Integer totalPages;
	private String contents;
	private Integer isActive;
	private String keyword;

	// Constructors

	/** default constructor */
	public KnwTitle() {
	}


	// Property accessors


	public Integer getId() {
		return this.id;
	}

	public Integer getIsActive() {
		return isActive;
	}


	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}


	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTypeId() {
		return this.typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return this.typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getSource() {
		return this.source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Date getIssuedDate() {
		return this.issuedDate;
	}

	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}

	public Short getIsAuthenticated() {
		return this.isAuthenticated;
	}

	public void setIsAuthenticated(Short isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}

	public Integer getTotalPages() {
		return this.totalPages;
	}

	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}

	public String getContents() {
		return this.contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}


	public String getKeyword() {
		return keyword;
	}


	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

}