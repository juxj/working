package com.zj198.action.loan.model;

import java.util.List;

import com.zj198.model.PrdExtendsProperty;
import com.zj198.model.PrdFinance;
import com.zj198.model.vo.FinanceAreaModel;
import com.zj198.model.vo.FinanceIndustryModel;

public class PreviewFinanceProSrModel {
	private PrdFinance product;
	private List<FinanceAreaModel> productAreaList;
	private List<FinanceIndustryModel> productIndustryList;
	private List<PrdExtendsProperty> extendsPropertyList;
	public PrdFinance getProduct() {
		return product;
	}
	public void setProduct(PrdFinance product) {
		this.product = product;
	}
	public List<FinanceAreaModel> getProductAreaList() {
		return productAreaList;
	}
	public void setProductAreaList(List<FinanceAreaModel> productAreaList) {
		this.productAreaList = productAreaList;
	}
	public List<FinanceIndustryModel> getProductIndustryList() {
		return productIndustryList;
	}
	public void setProductIndustryList(
			List<FinanceIndustryModel> productIndustryList) {
		this.productIndustryList = productIndustryList;
	}
	public List<PrdExtendsProperty> getExtendsPropertyList() {
		return extendsPropertyList;
	}
	public void setExtendsPropertyList(List<PrdExtendsProperty> extendsPropertyList) {
		this.extendsPropertyList = extendsPropertyList;
	}
}
