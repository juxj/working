package com.zj198.action.admin.system;

import com.zj198.action.BaseAction;

public class SysParameterAction extends BaseAction {

	
	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}

}
