package com.zj198.dao.hibernate;

import com.zj198.dao.DicBaseRateDAO;
import com.zj198.model.DicBaseRate;

public class DicBaseRateDAOImpl  extends HibernateDAO<DicBaseRate, Integer> implements  DicBaseRateDAO{

}
