package com.zj198.dao;

import java.util.List;

import com.zj198.model.UsrServiceorg;

public interface UsrServiceorgDAO extends BaseDAO<UsrServiceorg, Integer>{
	public UsrServiceorg getByUid(Integer uid);
	public List<UsrServiceorg> findUsrServiceOrgsByName(String name);
}
