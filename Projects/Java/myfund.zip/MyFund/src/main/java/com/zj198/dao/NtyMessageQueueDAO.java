package com.zj198.dao;

import java.util.List;

import com.zj198.model.NtyMessageQueue;

public interface NtyMessageQueueDAO extends BaseDAO<NtyMessageQueue, Long> {
	public List<NtyMessageQueue> findByStatusType(int status,int type);
}
