package com.zj198.model.vo;

public class ValueSetModel {
	private String key;
	private String value;
	public ValueSetModel(String k, String v){
		this.key = k;
		this.value = v;
	}

	public String getValueByKey(String key){
		return value;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
}
