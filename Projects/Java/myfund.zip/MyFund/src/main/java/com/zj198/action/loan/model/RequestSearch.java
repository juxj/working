package com.zj198.action.loan.model;

import java.util.Date;

public class RequestSearch {

	private String applyNum;
	private String busiName;
	private String loanPurpose;
	private String companyType;
	private Date createdtFirst;
	private Date createdtSecond;
	private Long loanAmountOne;
	private Long loanAmountTwo;
	private Integer loanMonthOne;
	private Integer loanMonthTwo;
	private Integer userType;

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public String getApplyNum() {
		return applyNum;
	}

	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}

	public String getBusiName() {
		return busiName;
	}

	public void setBusiName(String busiName) {
		this.busiName = busiName;
	}

	public String getLoanPurpose() {
		return loanPurpose;
	}

	public void setLoanPurpose(String loanPurpose) {
		this.loanPurpose = loanPurpose;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public Date getCreatedtFirst() {
		return createdtFirst;
	}

	public void setCreatedtFirst(Date createdtFirst) {
		this.createdtFirst = createdtFirst;
	}

	public Date getCreatedtSecond() {
		return createdtSecond;
	}

	public void setCreatedtSecond(Date createdtSecond) {
		this.createdtSecond = createdtSecond;
	}

	public Long getLoanAmountOne() {
		return loanAmountOne;
	}

	public void setLoanAmountOne(Long loanAmountOne) {
		this.loanAmountOne = loanAmountOne;
	}

	public Long getLoanAmountTwo() {
		return loanAmountTwo;
	}

	public void setLoanAmountTwo(Long loanAmountTwo) {
		this.loanAmountTwo = loanAmountTwo;
	}

	public Integer getLoanMonthOne() {
		return loanMonthOne;
	}

	public void setLoanMonthOne(Integer loanMonthOne) {
		this.loanMonthOne = loanMonthOne;
	}

	public Integer getLoanMonthTwo() {
		return loanMonthTwo;
	}

	public void setLoanMonthTwo(Integer loanMonthTwo) {
		this.loanMonthTwo = loanMonthTwo;
	}

}
