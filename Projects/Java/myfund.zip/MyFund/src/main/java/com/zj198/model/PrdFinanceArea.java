package com.zj198.model;

/**
 * OrdFinanceArea entity. @author MyEclipse Persistence Tools
 */

public class PrdFinanceArea implements java.io.Serializable {

	private static final long serialVersionUID = 4844566173165848190L;
	private Integer id;
	private Integer financeId;
	private Integer provinceId;
	private Integer cityId;

	/** default constructor */
	public PrdFinanceArea() {
	}
	
	public PrdFinanceArea(Integer id,Integer financeId,Integer provinceId,Integer cityId) {
		this.id=id;
		this.financeId = financeId;
		this.provinceId = provinceId;
		this.cityId = cityId;
	}


	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getFinanceId() {
		return this.financeId;
	}

	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}

	public Integer getProvinceId() {
		return this.provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	public Integer getCityId() {
		return this.cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

}