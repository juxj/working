package com.zj198.dao;

import java.util.List;

import com.zj198.model.KnwType;

public interface KnwTypeDAO extends BaseDAO<KnwType, Integer> {

}
