package com.zj198.action.loan.model;

import java.io.File;

public class AppLoanAttachSpModel {
	private File upload;
	private String uploadFileName;
	private String uploadContentType;
	private Integer appLoanId;
	private Integer userId;
	private Integer loanDataId;
	public Integer getLoanDataId() {
		return loanDataId;
	}
	public void setLoanDataId(Integer loanDataId) {
		this.loanDataId = loanDataId;
	}
	public File getUpload() {
		return upload;
	}
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public String getUploadFileName() {
		return uploadFileName;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public String getUploadContentType() {
		return uploadContentType;
	}
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}
	public Integer getAppLoanId() {
		return appLoanId;
	}
	public void setAppLoanId(Integer appLoanId) {
		this.appLoanId = appLoanId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
}
