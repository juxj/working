package com.zj198.model;

import java.util.Date;

/**
 * OrdFinanceApplyAttach entity. @author MyEclipse Persistence Tools
 */

public class OrdFinanceApplyAttach implements java.io.Serializable {

	private static final long serialVersionUID = 1683393277190376699L;
	private Integer id;
	private Integer applyId;
	private Integer datalistId;
	private Integer financeDataId;
	private String oldFileName;
	private String fileName;
	private String uploadPath;
	private Date createdt;
	private Date updatedt;
	private Integer createUserId;
	private Integer uploadStatus;
	private Integer checkStatus;
	private Integer attachType;
	private String supplyName;
	private String supplyMemo;
	private String supplyWay;
	private Integer isdeleted;
	private Date supplyCreatedt;

	/** default constructor */
	public OrdFinanceApplyAttach() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getApplyId() {
		return this.applyId;
	}

	public void setApplyId(Integer applyId) {
		this.applyId = applyId;
	}

	public Integer getDatalistId() {
		return this.datalistId;
	}

	public void setDatalistId(Integer datalistId) {
		this.datalistId = datalistId;
	}

	public Integer getFinanceDataId() {
		return this.financeDataId;
	}

	public void setFinanceDataId(Integer financeDataId) {
		this.financeDataId = financeDataId;
	}

	public String getOldFileName() {
		return this.oldFileName;
	}

	public void setOldFileName(String oldFileName) {
		this.oldFileName = oldFileName;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getUploadPath() {
		return this.uploadPath;
	}

	public void setUploadPath(String uploadPath) {
		this.uploadPath = uploadPath;
	}

	public Date getCreatedt() {
		return this.createdt;
	}

	public void setCreatedt(Date createdt) {
		this.createdt = createdt;
	}

	public Date getUpdatedt() {
		return this.updatedt;
	}

	public void setUpdatedt(Date updatedt) {
		this.updatedt = updatedt;
	}

	public Integer getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(Integer createUserId) {
		this.createUserId = createUserId;
	}

	public Integer getUploadStatus() {
		return this.uploadStatus;
	}

	public void setUploadStatus(Integer uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	public Integer getCheckStatus() {
		return this.checkStatus;
	}

	public void setCheckStatus(Integer checkStatus) {
		this.checkStatus = checkStatus;
	}

	public Integer getAttachType() {
		return this.attachType;
	}

	public void setAttachType(Integer attachType) {
		this.attachType = attachType;
	}

	public String getSupplyName() {
		return this.supplyName;
	}

	public void setSupplyName(String supplyName) {
		this.supplyName = supplyName;
	}

	public String getSupplyMemo() {
		return this.supplyMemo;
	}

	public void setSupplyMemo(String supplyMemo) {
		this.supplyMemo = supplyMemo;
	}

	

	public Integer getIsdeleted() {
		return this.isdeleted;
	}

	public void setIsdeleted(Integer isdeleted) {
		this.isdeleted = isdeleted;
	}

	public Date getSupplyCreatedt() {
		return this.supplyCreatedt;
	}

	public void setSupplyCreatedt(Date supplyCreatedt) {
		this.supplyCreatedt = supplyCreatedt;
	}

	public String getSupplyWay() {
		return supplyWay;
	}

	public void setSupplyWay(String supplyWay) {
		this.supplyWay = supplyWay;
	}

}