package com.zj198.dao;

import com.zj198.model.UsrFunction;

public interface UsrFunctionDAO extends BaseDAO<UsrFunction, Integer> {

}
