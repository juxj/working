package com.zj198.dao;

import com.zj198.model.DicBank;

public interface DicBankDAO extends BaseDAO<DicBank, Integer> {

}
