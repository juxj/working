package com.zj198.action.common;

import java.util.List;

import com.zj198.action.BaseAction;
import com.zj198.model.KnwTitle;
import com.zj198.model.KnwType;
import com.zj198.model.PrdBankfinance;
import com.zj198.model.PrdFinance;
import com.zj198.model.PrdRecommendation;
import com.zj198.model.PrdServiceItem;
import com.zj198.service.finservice.FinanceProdService;
import com.zj198.service.loan.FinanceProductService;
import com.zj198.service.news.NewsService;
import com.zj198.service.sin.ServiceInfoService;
import com.zj198.util.Constants;

public class IndexAction extends BaseAction{
	
	private List<PrdBankfinance> bankFinanceList;
	/*首页公告*/
	private List<KnwTitle> announcements;
	/*融资案例*/
	private List<KnwTitle> financingCases;
	/*新闻-政府动态*/
	private List<KnwTitle> govermentNews;
	/*新闻-金融快讯*/
	private List<KnwTitle> financeNews;
	/*新闻-资金网动态*/
	private List<KnwTitle> siteNews;
	
	private List<PrdRecommendation> bankFinanceRecommendationList;
	
	private List<KnwType> newsTypeList;
	private List<PrdServiceItem> serviceItemList;
	private List<PrdFinance> prdFinanceList;
	
	private FinanceProdService financeProdService;
	private NewsService newsService;
	private ServiceInfoService serviceInfoService;
//	private SupplyRequestService supplyRequestService;
	private FinanceProductService financeProductService;
	
//	ActionContext context = ActionContext.getContext();
//	Map<String, Object> application = context.getApplication();
	
	//整站首页
	public String execute(){
		bankFinanceList = financeProdService.findByBenefitRate(3);
		this.getNewsRelatedData();
		this.getServiceInfoList();
//		this.getSupplyRequestData();
		this.getImportentProduct();
		return SUCCESS;
	}
	public void getImportentProduct(){
		prdFinanceList = financeProductService.findFinanceImportent(new Integer(4));
		this.bankFinanceRecommendationList = this.financeProdService.findRecommendationByTopNumber(1,4);
	}
	//整站首页
	public String building(){
		return "building";
	}
	private void getServiceInfoList() {
		this.serviceItemList = this.serviceInfoService.findPrdServiceItemByRecentN(5);
	}
	
	private void getNewsRelatedData() {
		//滚动新闻.
		this.announcements = newsService.findLastestByType(Constants.ANNOUNCED_NEWS,5);
		//融资案例
		this.financingCases = newsService.findLastestByType(Constants.FINANCING_CASE,5);
		//政府动态
		this.govermentNews = newsService.findLastestByType(Constants.GOVERMENT_NEWS,5);
		//金融资讯
		this.financeNews = newsService.findLastestByType(Constants.FINANCE_NEWS,5);
		//资金网动态
		this.siteNews = newsService.findLastestByType(Constants.SITE_NEWS,5);
	}
	
	
//	/**供求信息*/
//	private void getSupplyRequestData(){
//		if (Constants.SUPPLY_INFO_LIST != null) {
//			Pager page = this.supplyRequestService.findClbSupplyInfoList(10, 1);
//			Constants.SUPPLY_INFO_LIST = page.getData();
//		}
//		
//		if (Constants.REQUEST_INFO_LIST !=null){
//			Pager page = this.supplyRequestService.findRequestInfoList(10, 1);
//			Constants.REQUEST_INFO_LIST = page.getData();
//		}
//	}
	
	//setter and getter
	public List<PrdBankfinance> getBankFinanceList() {
		return bankFinanceList;
	}
	public List<KnwType> getNewsTypeList() {
		return newsTypeList;
	}
	public void setFinanceProdService(FinanceProdService financeProdService) {
		this.financeProdService = financeProdService;
	}
	public List<KnwTitle> getAnnouncements() {
		return announcements;
	}
	public void setAnnouncements(List<KnwTitle> announcements) {
		this.announcements = announcements;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	public List<PrdServiceItem> getServiceItemList() {
		return serviceItemList;
	}
	public void setServiceInfoService(ServiceInfoService serviceInfoService) {
		this.serviceInfoService = serviceInfoService;
	}
	public List<KnwTitle> getFinancingCases() {
		return financingCases;
	}
	public List<KnwTitle> getGovermentNews() {
		return govermentNews;
	}
	public List<KnwTitle> getFinanceNews() {
		return financeNews;
	}
	public List<KnwTitle> getSiteNews() {
		return siteNews;
	}
//	public void setSupplyRequestService(SupplyRequestService supplyRequestService) {
//		this.supplyRequestService = supplyRequestService;
//	}
	public List<PrdFinance> getPrdFinanceList() {
		return prdFinanceList;
	}
	public void setPrdFinanceList(List<PrdFinance> prdFinanceList) {
		this.prdFinanceList = prdFinanceList;
	}
	public void setFinanceProductService(FinanceProductService financeProductService) {
		this.financeProductService = financeProductService;
	}
	public List<PrdRecommendation> getBankFinanceRecommendationList() {
		return bankFinanceRecommendationList;
	}
	
}
