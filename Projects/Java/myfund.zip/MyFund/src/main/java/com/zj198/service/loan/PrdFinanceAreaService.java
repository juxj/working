package com.zj198.service.loan;

import java.util.List;

import com.zj198.model.vo.FinanceAreaModel;

public interface PrdFinanceAreaService {
	
	public List<FinanceAreaModel> findFiananceArea(Integer financeId);

}
