package com.zj198.util.tag;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.opensymphony.xwork2.util.ValueStack;

public class CheckboxCommon  extends CommonListUIBean
{
	  public static final String TEMPLATE = "checkboxlist";

	  public CheckboxCommon(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
	  {
	    super(stack, request, response);
	  }

	  protected String getDefaultTemplate() {
	    return "checkboxlist";
	  }
	}