package com.zj198.dao;

import com.zj198.model.UsrContract;
import com.zj198.model.UsrUser;
import com.zj198.util.Pager;

public interface UsrContractDAO extends BaseDAO<UsrContract, Integer> {

	public Pager findUserContracts(Integer userId, int pageSize, int pageNo);
	
	public Pager findUserContracts(int pageSize, int pageNo);
}
