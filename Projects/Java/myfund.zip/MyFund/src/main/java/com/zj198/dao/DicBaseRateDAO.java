package com.zj198.dao;

import com.zj198.model.DicBaseRate;

public interface DicBaseRateDAO  extends BaseDAO<DicBaseRate, Integer>{

}
