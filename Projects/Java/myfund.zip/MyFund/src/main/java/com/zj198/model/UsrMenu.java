package com.zj198.model;

/**
 * UsrMenu entity. @author MyEclipse Persistence Tools
 */

public class UsrMenu implements java.io.Serializable {

	private static final long serialVersionUID = -8286236914772275879L;
	private Integer id;
	private String menuname;
	private String action;
	private Integer parentid;
	private Integer rights;

	/** default constructor */
	public UsrMenu() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMenuname() {
		return this.menuname;
	}

	public void setMenuname(String menuname) {
		this.menuname = menuname;
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Integer getParentid() {
		return this.parentid;
	}

	public void setParentid(Integer parentid) {
		this.parentid = parentid;
	}

	public Integer getRights() {
		return this.rights;
	}

	public void setRights(Integer rights) {
		this.rights = rights;
	}

}