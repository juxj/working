package com.zj198.dao;

import java.util.List;

import com.zj198.model.DicYellowpage;

public interface DicYellowpageDAO extends BaseDAO<DicYellowpage, Integer> {

	public List<DicYellowpage> findPageByType(Integer type);

	public List<DicYellowpage> findPageByTypeAll(Integer type);
}
