package com.zj198.action.loan.model;

import java.util.Date;

public class FinanceProductExtendModel{
	private Integer companyAllAsset;
	private Integer operatIncome;
	private Integer settingYear;
	private String otherRequire;
	private String proIntroduce;
	private Integer proSpecial;
	private Integer uploadWay;
	private Integer needEnsure;
	private Integer experience;
	private Integer runningArea;
	private Integer bankSalaryList;
	private Integer creditAcount;
	private Integer salaryIncome;
	private Integer salaryPutWay;
	private Integer workTime;
	private Integer house;
	private String houseProperty;
	private Integer useTime;
	private Integer surplus;
	public Integer getCompanyAllAsset() {
		return companyAllAsset;
	}
	public void setCompanyAllAsset(Integer companyAllAsset) {
		this.companyAllAsset = companyAllAsset;
	}
	public Integer getOperatIncome() {
		return operatIncome;
	}
	public void setOperatIncome(Integer operatIncome) {
		this.operatIncome = operatIncome;
	}
	public Integer getSettingYear() {
		return settingYear;
	}
	public void setSettingYear(Integer settingYear) {
		this.settingYear = settingYear;
	}
	public String getOtherRequire() {
		return otherRequire;
	}
	public void setOtherRequire(String otherRequire) {
		this.otherRequire = otherRequire;
	}
	public String getProIntroduce() {
		return proIntroduce;
	}
	public void setProIntroduce(String proIntroduce) {
		this.proIntroduce = proIntroduce;
	}
	public Integer getProSpecial() {
		return proSpecial;
	}
	public void setProSpecial(Integer proSpecial) {
		this.proSpecial = proSpecial;
	}
	public Integer getUploadWay() {
		return uploadWay;
	}
	public void setUploadWay(Integer uploadWay) {
		this.uploadWay = uploadWay;
	}
	public Integer getNeedEnsure() {
		return needEnsure;
	}
	public void setNeedEnsure(Integer needEnsure) {
		this.needEnsure = needEnsure;
	}
	public Integer getExperience() {
		return experience;
	}
	public void setExperience(Integer experience) {
		this.experience = experience;
	}
	public Integer getRunningArea() {
		return runningArea;
	}
	public void setRunningArea(Integer runningArea) {
		this.runningArea = runningArea;
	}
	public Integer getBankSalaryList() {
		return bankSalaryList;
	}
	public void setBankSalaryList(Integer bankSalaryList) {
		this.bankSalaryList = bankSalaryList;
	}
	public Integer getCreditAcount() {
		return creditAcount;
	}
	public void setCreditAcount(Integer creditAcount) {
		this.creditAcount = creditAcount;
	}
	public Integer getSalaryIncome() {
		return salaryIncome;
	}
	public void setSalaryIncome(Integer salaryIncome) {
		this.salaryIncome = salaryIncome;
	}
	public Integer getSalaryPutWay() {
		return salaryPutWay;
	}
	public void setSalaryPutWay(Integer salaryPutWay) {
		this.salaryPutWay = salaryPutWay;
	}
	public Integer getWorkTime() {
		return workTime;
	}
	public void setWorkTime(Integer workTime) {
		this.workTime = workTime;
	}
	public Integer getHouse() {
		return house;
	}
	public void setHouse(Integer house) {
		this.house = house;
	}
	public String getHouseProperty() {
		return houseProperty;
	}
	public void setHouseProperty(String houseProperty) {
		this.houseProperty = houseProperty;
	}
	public Integer getUseTime() {
		return useTime;
	}
	public void setUseTime(Integer useTime) {
		this.useTime = useTime;
	}
	public Integer getSurplus() {
		return surplus;
	}
	public void setSurplus(Integer surplus) {
		this.surplus = surplus;
	}
}
