package com.zj198.dao.hibernate;
import com.zj198.dao.OrdFinanceAppLoanDAO;
import com.zj198.model.OrdFinanceAppLoan;
/**
 * @author 岳龙
 * Description:
 * CreateAuthor:岳龙
 * CreateDate:2012-7-17 15:47:30
 */
public class OrdFinanceAppLoanDAOImpl extends HibernateDAO<OrdFinanceAppLoan, Integer> implements OrdFinanceAppLoanDAO {
}
