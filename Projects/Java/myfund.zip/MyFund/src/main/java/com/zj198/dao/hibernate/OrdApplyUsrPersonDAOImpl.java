package com.zj198.dao.hibernate;

import com.zj198.dao.OrdApplyUsrPersonDAO;
import com.zj198.model.OrdApplyUsrPerson;

public class OrdApplyUsrPersonDAOImpl extends HibernateDAO<OrdApplyUsrPerson, Integer> implements OrdApplyUsrPersonDAO {

	
}
