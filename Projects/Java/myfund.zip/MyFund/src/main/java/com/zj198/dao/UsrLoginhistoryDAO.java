package com.zj198.dao;

import com.zj198.model.UsrLoginhistory;

public interface UsrLoginhistoryDAO extends BaseDAO<UsrLoginhistory, Integer> {
	/**
	 * 通过用户id查询出最后一次登录的时间
	 * @param uid
	 * @return null
	 */
	public UsrLoginhistory getLastByUid(Integer uid);
}
