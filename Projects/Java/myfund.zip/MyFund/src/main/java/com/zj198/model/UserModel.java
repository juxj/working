package com.zj198.model;

public class UserModel implements java.io.Serializable {

	/**
	 * 因不同的用户类型对应不同的表，此类用于存储所有用户的模糊查询值。
	 */
	private static final long serialVersionUID = 3079233505443088308L;
	
	private Integer id;
	private String name;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
