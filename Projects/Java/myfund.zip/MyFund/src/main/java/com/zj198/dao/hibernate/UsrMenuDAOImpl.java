package com.zj198.dao.hibernate;

import com.zj198.dao.UsrMenuDAO;
import com.zj198.model.UsrMenu;

public class UsrMenuDAOImpl extends HibernateDAO<UsrMenu, Integer> implements UsrMenuDAO {

}
