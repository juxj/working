package com.zj198.model;

/**
 * NtyReceiver entity. @author MyEclipse Persistence Tools
 */

public class NtyReceiver implements java.io.Serializable {

	private static final long serialVersionUID = -6864120338820983204L;
	private Long id;
	private Integer receiver;
	private Integer isReceiverDeleted;
	private Long messageid;
	private Integer isRead;

	/** default constructor */
	public NtyReceiver() {
	}

	// Property accessors
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getReceiver() {
		return this.receiver;
	}

	public void setReceiver(Integer receiver) {
		this.receiver = receiver;
	}

	public Integer getIsReceiverDeleted() {
		return this.isReceiverDeleted;
	}

	public void setIsReceiverDeleted(Integer isReceiverDeleted) {
		this.isReceiverDeleted = isReceiverDeleted;
	}

	public Long getMessageid() {
		return this.messageid;
	}

	public void setMessageid(Long messageid) {
		this.messageid = messageid;
	}

	public Integer getIsRead() {
		return isRead;
	}

	public void setIsRead(Integer isRead) {
		this.isRead = isRead;
	}

}