package com.zj198.action.admin.user;

public class MySupplyRequestAction {
	
	public String listMyPost(){
		return null;
	}
	
	public String postSupply(){
		return null;
	}
	
	public String postRequest(){
		return null;
	}
}
