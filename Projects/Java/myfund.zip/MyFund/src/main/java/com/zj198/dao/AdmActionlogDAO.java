package com.zj198.dao;

import com.zj198.model.AdmActionlog;


/**
 * AdmActionlog entity. @author MyEclipse Persistence Tools
 */

public interface AdmActionlogDAO extends BaseDAO<AdmActionlog,Long> {


}