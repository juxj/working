package com.zj198.dao;

import java.util.List;

import com.zj198.model.UsrCompany;

public interface UsrCompanyDAO extends BaseDAO<UsrCompany, Integer> {
	public UsrCompany getByUid(Integer uid);
	
	public List<UsrCompany> findUsrCompaniesByName(String name);
}
