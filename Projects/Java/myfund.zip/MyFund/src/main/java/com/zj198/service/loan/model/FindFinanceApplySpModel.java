package com.zj198.service.loan.model;

import com.zj198.model.UsrUser;

public class FindFinanceApplySpModel {
	private UsrUser user;
	private Integer showNumber = 3;

	public Integer getShowNumber() {
		return showNumber;
	}

	public void setShowNumber(Integer showNumber) {
		this.showNumber = showNumber;
	}

	public UsrUser getUser() {
		return user;
	}

	public void setUser(UsrUser user) {
		this.user = user;
	}
	
}
