package com.zj198.service;

public abstract class BaseService {

}
