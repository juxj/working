package com.zj198.model;

/**
 * AdmFunction entity. @author MyEclipse Persistence Tools
 */

public class AdmFunction implements java.io.Serializable {

	private static final long serialVersionUID = 1295705126163993204L;
	private Integer id;
	private String action;
	private Long rights;
	private Short ismenu;
	private String remarks;
	private Integer parentid;

	/** default constructor */
	public AdmFunction() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getParentid() {
		return parentid;
	}

	public void setParentid(Integer parentid) {
		this.parentid = parentid;
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Long getRights() {
		return this.rights;
	}

	public void setRights(Long rights) {
		this.rights = rights;
	}

	public Short getIsmenu() {
		return this.ismenu;
	}

	public void setIsmenu(Short ismenu) {
		this.ismenu = ismenu;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}