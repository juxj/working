package com.zj198.util.tag;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.opensymphony.xwork2.util.ValueStack;

public class RadioCommon extends CommonListUIBean
{
	  public static final String TEMPLATE = "radiomap";

	  public RadioCommon(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
	  {
	    super(stack, request, response);
	  }

	  protected String getDefaultTemplate() {
	    return "radiomap";
	  }
	}
