package com.zj198.model;

/**
 * DicDistrict entity. @author MyEclipse Persistence Tools
 */

public class DicDistrict implements java.io.Serializable {

	private static final long serialVersionUID = 6889452086408758865L;
	private Integer id;
	private Integer cityid;
	private String name;

	/** default constructor */
	public DicDistrict() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCityid() {
		return this.cityid;
	}

	public void setCityid(Integer cityid) {
		this.cityid = cityid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}