package com.zj198.model;

/**
 * UsrFunction entity. @author MyEclipse Persistence Tools
 */

public class UsrFunction implements java.io.Serializable {

	private static final long serialVersionUID = -7914653279987394111L;
	private Integer id;
	private String action;
	private String rights;
	private String remarks;

	/** default constructor */
	public UsrFunction() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getRights() {
		return this.rights;
	}

	public void setRights(String rights) {
		this.rights = rights;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}