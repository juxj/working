package com.zj198.dao.hibernate;


import com.zj198.dao.KnwTypeDAO;
import com.zj198.model.KnwType;

public class KnwTypeDAOImpl extends HibernateDAO<KnwType, Integer> implements KnwTypeDAO {

}
