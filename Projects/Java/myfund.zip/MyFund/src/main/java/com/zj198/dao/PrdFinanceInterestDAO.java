package com.zj198.dao;

import java.util.List;

import com.zj198.model.PrdFinanceInterest;

/**
 * @author 岳龙
 * Description:
 * CreateAuthor:岳龙
 * CreateDate:2012-7-05 15:09:59
 */
public interface PrdFinanceInterestDAO extends BaseDAO<PrdFinanceInterest, Integer>{
//	public List<OrdFinanceInterest> findInterestByPro(Integer productId);
	public List<PrdFinanceInterest> findInterest(Integer financeId);
}
