package com.zj198.model;

/**
 * OrdDatafileList entity. @author MyEclipse Persistence Tools
 */

public class PrdDatafileList implements java.io.Serializable {

	private static final long serialVersionUID = 2317185919776618721L;
	private Integer id;
	private String dataName;
	private Integer orderNo;
	private Integer haveMemo;
	private String selectStatus;
	private Integer dataNum;
	private String dataMemo;
	private String otherMemo;

	/** default constructor */
	public PrdDatafileList() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDataName() {
		return this.dataName;
	}

	public void setDataName(String dataName) {
		this.dataName = dataName;
	}

	public Integer getOrderNo() {
		return this.orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public Integer getHaveMemo() {
		return haveMemo;
	}

	public void setHaveMemo(Integer haveMemo) {
		this.haveMemo = haveMemo;
	}

	public String getSelectStatus() {
		return selectStatus;
	}

	public void setSelectStatus(String selectStatus) {
		this.selectStatus = selectStatus;
	}

	public Integer getDataNum() {
		return dataNum;
	}

	public void setDataNum(Integer dataNum) {
		this.dataNum = dataNum;
	}

	public String getDataMemo() {
		return dataMemo;
	}

	public void setDataMemo(String dataMemo) {
		this.dataMemo = dataMemo;
	}

	public String getOtherMemo() {
		return otherMemo;
	}

	public void setOtherMemo(String otherMemo) {
		this.otherMemo = otherMemo;
	}

}