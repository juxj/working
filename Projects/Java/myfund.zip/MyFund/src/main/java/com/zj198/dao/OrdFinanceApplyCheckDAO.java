package com.zj198.dao;

import java.util.List;

import com.zj198.model.OrdFinanceApplyCheck;

/**
 * @author 岳龙
 * Description:
 * CreateAuthor:岳龙
 * CreateDate:2012-7-05 15:09:59
 */
public interface OrdFinanceApplyCheckDAO extends BaseDAO<OrdFinanceApplyCheck, Integer>{
	public List<OrdFinanceApplyCheck> findApplyCheck(Integer applyId);
	public List<OrdFinanceApplyCheck> findApplyCheck(Integer applyId,Integer num);
}
