package com.zj198.dao;

import com.zj198.model.DicProvince;

public interface DicProvinceDAO extends BaseDAO<DicProvince, Integer> {

}
