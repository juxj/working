package com.zj198.dao;

import java.util.List;

import com.zj198.model.DicIndustry;

public interface DicIndustryDAO extends BaseDAO<DicIndustry, Integer> {
	public List<DicIndustry> findByParentid(Integer parentId);
}
