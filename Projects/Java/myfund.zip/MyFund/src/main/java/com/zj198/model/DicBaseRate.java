package com.zj198.model;

/**
 * OrdBaseRate entity. @author MyEclipse Persistence Tools
 */

public class DicBaseRate implements java.io.Serializable {

	private static final long serialVersionUID = -8014372173766199560L;
	private Integer id;
	private Integer startdt;
	private Integer enddt;
	private Double rate;
	private String memo;

	/** default constructor */
	public DicBaseRate() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getStartdt() {
		return this.startdt;
	}

	public void setStartdt(Integer startdt) {
		this.startdt = startdt;
	}

	public Integer getEnddt() {
		return this.enddt;
	}

	public void setEnddt(Integer enddt) {
		this.enddt = enddt;
	}

	public Double getRate() {
		return this.rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

}