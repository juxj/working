package com.zj198.model;

/**
 * DicYellowpage entity. @author MyEclipse Persistence Tools
 */

public class DicYellowpage implements java.io.Serializable {

	private static final long serialVersionUID = 3620389802956590228L;
	private Integer id;
	private Integer type;
	private String subtypename;
	private String url;
	private String name;

	/** default constructor */
	public DicYellowpage() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getType() {
		return this.type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getSubtypename() {
		return this.subtypename;
	}

	public void setSubtypename(String subtypename) {
		this.subtypename = subtypename;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}