package com.zj198.model;

/**
 * SinType entity. @author MyEclipse Persistence Tools
 */

public class DicServiceType implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 4837218736036348676L;
	private Integer id;
	private String name;
	private Short isCancelled;

	// Constructors

	/** default constructor */
	public DicServiceType() {
	}

	/** full constructor */
	public DicServiceType(String name, Short isCancelled) {
		this.name = name;
		this.isCancelled = isCancelled;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Short getIsCancelled() {
		return this.isCancelled;
	}

	public void setIsCancelled(Short isCancelled) {
		this.isCancelled = isCancelled;
	}

}