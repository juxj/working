package com.zj198.model;

import java.util.Date;


/**
 * OrdLrRecommend entity. @author MyEclipse Persistence Tools
 */

public class OrdLrRecommend implements java.io.Serializable {

	private static final long serialVersionUID = -359284378120338480L;
	private Integer id;
	private Integer requestId;
	private Integer financeId;
	private Date createdt;
	private Integer createUserId;
	private Integer recommendType;

	/** default constructor */
	public OrdLrRecommend() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRequestId() {
		return this.requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public Integer getFinanceId() {
		return this.financeId;
	}

	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}

	public Date getCreatedt() {
		return this.createdt;
	}

	public void setCreatedt(Date createdt) {
		this.createdt = createdt;
	}

	public Integer getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(Integer createUserId) {
		this.createUserId = createUserId;
	}

	public Integer getRecommendType() {
		return recommendType;
	}

	public void setRecommendType(Integer recommendType) {
		this.recommendType = recommendType;
	}

}