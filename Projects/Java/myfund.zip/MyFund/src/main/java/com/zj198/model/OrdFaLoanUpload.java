package com.zj198.model;

import java.util.Date;


/**
 * OrdFaLoanUpload entity. @author MyEclipse Persistence Tools
 */

public class OrdFaLoanUpload implements java.io.Serializable {

	private static final long serialVersionUID = -7232367208092125199L;
	private Integer id;
	private Integer dataId;
	private String oldFileName;
	private String fileName;
	private String uploadPath;
	private Date createdt;
	private Date updatedt;
	private Integer createUserId;

	/** default constructor */
	public OrdFaLoanUpload() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDataId() {
		return this.dataId;
	}

	public void setDataId(Integer dataId) {
		this.dataId = dataId;
	}

	public String getOldFileName() {
		return this.oldFileName;
	}

	public void setOldFileName(String oldFileName) {
		this.oldFileName = oldFileName;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getUploadPath() {
		return this.uploadPath;
	}

	public void setUploadPath(String uploadPath) {
		this.uploadPath = uploadPath;
	}

	public Date getCreatedt() {
		return this.createdt;
	}

	public void setCreatedt(Date createdt) {
		this.createdt = createdt;
	}

	public Date getUpdatedt() {
		return this.updatedt;
	}

	public void setUpdatedt(Date updatedt) {
		this.updatedt = updatedt;
	}

	public Integer getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(Integer createUserId) {
		this.createUserId = createUserId;
	}

}