package com.zj198.dao;

import java.util.List;

import com.zj198.model.AdmFunction;

/**
 * AdmFunction entity. @author MyEclipse Persistence Tools
 */

public interface AdmFunctionDAO extends BaseDAO<AdmFunction,Integer>{

	public List<AdmFunction> findAllMenu();
	public AdmFunction getByActionName(String actionName);
}