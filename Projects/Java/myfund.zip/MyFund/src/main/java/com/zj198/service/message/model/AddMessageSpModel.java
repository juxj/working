package com.zj198.service.message.model;

import com.zj198.model.NtyMessage;

public class AddMessageSpModel {
	private NtyMessage message;
	private Integer[] receiverId;
	private Integer sendUserId;
	public NtyMessage getMessage() {
		return message;
	}
	public void setMessage(NtyMessage message) {
		this.message = message;
	}
	public Integer[] getReceiverId() {
		return receiverId;
	}
	public void setReceiverId(Integer[] receiverId) {
		this.receiverId = receiverId;
	}
	public Integer getSendUserId() {
		return sendUserId;
	}
	public void setSendUserId(Integer sendUserId) {
		this.sendUserId = sendUserId;
	}
}
