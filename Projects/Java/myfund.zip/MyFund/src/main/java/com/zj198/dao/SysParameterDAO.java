package com.zj198.dao;

import com.zj198.model.SysParameter;

public interface SysParameterDAO extends BaseDAO<SysParameter, Integer> {

}
