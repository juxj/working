package com.zj198.dao;

import com.zj198.model.OrdApplyUsrPerson;

public interface OrdApplyUsrPersonDAO extends BaseDAO<OrdApplyUsrPerson, Integer> {

}
