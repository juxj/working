package com.zj198.dao;

import com.zj198.model.PrdFinanceDatafile;

/**
 * @author 岳龙
 * Description:
 * CreateAuthor:岳龙
 * CreateDate:2012-7-05 14:54:57
 */
public interface PrdFinanceDatafileDAO 
	extends BaseDAO<PrdFinanceDatafile, Integer>{
	public PrdFinanceDatafile findDataFile(Integer financeId, Integer dataId);
}
