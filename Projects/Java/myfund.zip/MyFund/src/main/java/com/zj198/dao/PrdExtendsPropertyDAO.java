package com.zj198.dao;

import java.util.List;

import com.zj198.model.PrdExtendsProperty;

public interface PrdExtendsPropertyDAO extends BaseDAO<PrdExtendsProperty, Integer>{
	public List<PrdExtendsProperty> getFinancePropertys(Integer financeId);
}