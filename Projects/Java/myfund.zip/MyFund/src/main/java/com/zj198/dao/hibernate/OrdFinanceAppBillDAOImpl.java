package com.zj198.dao.hibernate;
import com.zj198.dao.OrdFinanceAppBillDAO;
import com.zj198.model.OrdFinanceAppBill;
/**
 * @author 岳龙
 * Description:
 * CreateAuthor:岳龙
 * CreateDate:2012-7-17 15:47:30
 */
public class OrdFinanceAppBillDAOImpl extends HibernateDAO<OrdFinanceAppBill, Integer> implements OrdFinanceAppBillDAO {
}
