package com.zj198.model;

public class SinServiceLevel implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8382240021417354566L;
	private Integer id;
	private String  name;
	private Integer cnt;

	public SinServiceLevel(){}

	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public Integer getCnt() {
		return cnt;
	}

	public void setCnt(Integer cnt) {
		this.cnt = cnt;
	}


}
