package com.zj198.dao.hibernate;

import com.zj198.dao.DicBankDAO;
import com.zj198.model.DicBank;

public class DicBankDAOImpl extends HibernateDAO<DicBank, Integer> implements DicBankDAO {

}
