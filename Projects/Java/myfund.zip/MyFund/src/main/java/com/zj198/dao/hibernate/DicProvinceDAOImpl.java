package com.zj198.dao.hibernate;

import com.zj198.dao.DicProvinceDAO;
import com.zj198.model.DicProvince;

public class DicProvinceDAOImpl extends HibernateDAO<DicProvince, Integer> implements DicProvinceDAO{

}
