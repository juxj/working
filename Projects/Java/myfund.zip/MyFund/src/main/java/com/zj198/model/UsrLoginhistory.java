package com.zj198.model;

import java.util.Date;

/**
 * UsrLoginhistory entity. @author MyEclipse Persistence Tools
 */

public class UsrLoginhistory implements java.io.Serializable {

	private static final long serialVersionUID = -2456299380121399804L;
	private Integer id;
	private Integer uid;
	private Date logindt;
	private String loginip;

	/** default constructor */
	public UsrLoginhistory() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUid() {
		return this.uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public Date getLogindt() {
		return this.logindt;
	}

	public void setLogindt(Date logindt) {
		this.logindt = logindt;
	}

	public String getLoginip() {
		return this.loginip;
	}

	public void setLoginip(String loginip) {
		this.loginip = loginip;
	}

}