package com.zj198.model;

/**
 * DicCity entity. @author MyEclipse Persistence Tools
 */

public class DicCity implements java.io.Serializable {

	private static final long serialVersionUID = -1134742511236116642L;
	private Integer id;
	private Integer provinceid;
	private String name;

	/** default constructor */
	public DicCity() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getProvinceid() {
		return this.provinceid;
	}

	public void setProvinceid(Integer provinceid) {
		this.provinceid = provinceid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}