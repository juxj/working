package com.zj198.dao;

import java.util.List;

import com.zj198.model.PrdPropertyDic;

public interface PrdPropertyDicDAO extends BaseDAO<PrdPropertyDic, Integer>{
	public List<PrdPropertyDic> findPropertyDic(Integer groupId);
	public List<PrdPropertyDic> findPropertyDic(Integer groupId, String values);
}