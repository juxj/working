package com.zj198.model;

import java.util.Date;

/**
 * NtyMessage entity. @author MyEclipse Persistence Tools
 */

public class NtyMessage implements java.io.Serializable {

	private static final long serialVersionUID = -5027693650647455586L;
	private Long id;
	private String title;
	private String contents;
	private Date senddt;
	private Integer sender;
	private Integer isSenderDeleted;
	private Integer type;

	// Constructors
	/** default constructor */
	public NtyMessage() {
	}

	// Property accessors
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContents() {
		return this.contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public Date getSenddt() {
		return this.senddt;
	}

	public void setSenddt(Date senddt) {
		this.senddt = senddt;
	}

	public Integer getSender() {
		return this.sender;
	}

	public void setSender(Integer sender) {
		this.sender = sender;
	}

	public Integer getIsSenderDeleted() {
		return this.isSenderDeleted;
	}

	public void setIsSenderDeleted(Integer isSenderDeleted) {
		this.isSenderDeleted = isSenderDeleted;
	}

	public Integer getType() {
		return this.type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}