package com.zj198.model;

/**
 * DicUsertype entity. @author MyEclipse Persistence Tools
 */

public class DicUsertype implements java.io.Serializable {

	private static final long serialVersionUID = -2933452694511458900L;
	private Integer id;
	private String name;
	private Integer group;
	
	/** default constructor */
	public DicUsertype(){
	}
	
	// Property accessors
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getGroup() {
		return group;
	}
	public void setGroup(Integer group) {
		this.group = group;
	}
	
	
}
