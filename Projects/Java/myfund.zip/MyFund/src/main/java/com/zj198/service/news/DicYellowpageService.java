package com.zj198.service.news;

import java.util.List;

import com.zj198.model.DicYellowpage;

public interface DicYellowpageService {

	public List<DicYellowpage> findPageByType(Integer type);

	public List<DicYellowpage> findPageByTypeAll(Integer type);
}
