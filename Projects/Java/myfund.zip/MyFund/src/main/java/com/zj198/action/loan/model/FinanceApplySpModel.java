package com.zj198.action.loan.model;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.zj198.util.Pager;

public class FinanceApplySpModel {
	private Integer pageSize = 20;
	private Integer pageNo = 1;
//	private Pagination pagination;
	private Integer userId;
	
	private String applyNum;
	private String productName;
	private Integer applyType;
	private String userName;
	private Date applyStartDt;
	private Date applyEndDt;
	private Long applyAmountLittle;
	private Long applyAmountBig;
	private Integer startMonth;
	private Integer endMonth;
	private Integer applyStatus;
	private Pager pager;
	
	private List<String> extendsProValues;
	private Map paramap;
	
//	public Pagination getPagination() {
//		return pagination;
//	}
//	public void setPagination(Pagination pagination) {
//		this.pagination = pagination;
//	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getPageNo() {
		return pageNo;
	}
	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getApplyType() {
		return applyType;
	}
	public void setApplyType(Integer applyType) {
		this.applyType = applyType;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Date getApplyStartDt() {
		return applyStartDt;
	}
	public void setApplyStartDt(Date applyStartDt) {
		this.applyStartDt = applyStartDt;
	}
	public Date getApplyEndDt() {
		return applyEndDt;
	}
	public void setApplyEndDt(Date applyEndDt) {
		this.applyEndDt = applyEndDt;
	}
	public Long getApplyAmountLittle() {
		return applyAmountLittle;
	}
	public void setApplyAmountLittle(Long applyAmountLittle) {
		this.applyAmountLittle = applyAmountLittle;
	}
	public Long getApplyAmountBig() {
		return applyAmountBig;
	}
	public void setApplyAmountBig(Long applyAmountBig) {
		this.applyAmountBig = applyAmountBig;
	}
	public Integer getStartMonth() {
		return startMonth;
	}
	public void setStartMonth(Integer startMonth) {
		this.startMonth = startMonth;
	}
	public Integer getEndMonth() {
		return endMonth;
	}
	public void setEndMonth(Integer endMonth) {
		this.endMonth = endMonth;
	}
	public Integer getApplyStatus() {
		return applyStatus;
	}
	public void setApplyStatus(Integer applyStatus) {
		this.applyStatus = applyStatus;
	}
	public Pager getPager() {
		return pager;
	}
	public void setPager(Pager pager) {
		this.pager = pager;
	}
	public List<String> getExtendsProValues() {
		return extendsProValues;
	}
	public void setExtendsProValues(List<String> extendsProValues) {
		this.extendsProValues = extendsProValues;
	}
	public Map getParamap() {
		return paramap;
	}
	public void setParamap(Map paramap) {
		this.paramap = paramap;
	}
}
