package com.zj198.dao;

import java.util.List;

import com.zj198.model.UsrPerson;

public interface UsrPersonDAO extends BaseDAO<UsrPerson, Integer> {
	public UsrPerson getByUid(Integer uid);
}
