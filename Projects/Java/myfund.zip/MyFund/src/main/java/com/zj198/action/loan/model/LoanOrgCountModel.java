package com.zj198.action.loan.model;

public class LoanOrgCountModel {
	private Long bankNum;
	private Long littleLoan;
	private Long pawnOrg;
	private Long warrantOrg;
	private Long financeOrg;
	private Long insuranceOrg;
	private Long popularOrg;
	
	public Long getBankNum() {
		return bankNum;
	}
	public void setBankNum(Long bankNum) {
		this.bankNum = bankNum;
	}
	public Long getLittleLoan() {
		return littleLoan;
	}
	public void setLittleLoan(Long littleLoan) {
		this.littleLoan = littleLoan;
	}
	public Long getPawnOrg() {
		return pawnOrg;
	}
	public void setPawnOrg(Long pawnOrg) {
		this.pawnOrg = pawnOrg;
	}
	public Long getWarrantOrg() {
		return warrantOrg;
	}
	public void setWarrantOrg(Long warrantOrg) {
		this.warrantOrg = warrantOrg;
	}
	public Long getFinanceOrg() {
		return financeOrg;
	}
	public void setFinanceOrg(Long financeOrg) {
		this.financeOrg = financeOrg;
	}
	public Long getInsuranceOrg() {
		return insuranceOrg;
	}
	public void setInsuranceOrg(Long insuranceOrg) {
		this.insuranceOrg = insuranceOrg;
	}
	public Long getPopularOrg() {
		return popularOrg;
	}
	public void setPopularOrg(Long popularOrg) {
		this.popularOrg = popularOrg;
	}
}
