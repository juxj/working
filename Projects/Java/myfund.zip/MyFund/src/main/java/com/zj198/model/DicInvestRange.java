package com.zj198.model;

/**
 * DicInvestRange entity. @author MyEclipse Persistence Tools
 */

public class DicInvestRange implements java.io.Serializable {

	// Fields

	private static final long serialVersionUID = -6886267216790243289L;
	
	private Integer id;
	private String code;
	private String name;
	private Integer parentId;
	private String remark;
	private Integer paramTypeId;
	private String paramTypeName;

	// Constructors

	/** default constructor */
	public DicInvestRange() {
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getParentId() {
		return this.parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getParamTypeId() {
		return this.paramTypeId;
	}

	public void setParamTypeId(Integer paramTypeId) {
		this.paramTypeId = paramTypeId;
	}

	public String getParamTypeName() {
		return this.paramTypeName;
	}

	public void setParamTypeName(String paramTypeName) {
		this.paramTypeName = paramTypeName;
	}

}