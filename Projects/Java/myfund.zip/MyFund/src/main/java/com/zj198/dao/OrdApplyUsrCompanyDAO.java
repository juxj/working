package com.zj198.dao;

import com.zj198.model.OrdApplyUsrCompany;

public interface OrdApplyUsrCompanyDAO extends BaseDAO<OrdApplyUsrCompany, Integer> {

	public void add(OrdApplyUsrCompany o);

	public OrdApplyUsrCompany getByApplyId(Integer id);
}
