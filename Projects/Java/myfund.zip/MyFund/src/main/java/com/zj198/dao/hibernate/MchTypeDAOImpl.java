package com.zj198.dao.hibernate;

import com.zj198.dao.MchTypeDAO;
import com.zj198.model.MchType;

public class MchTypeDAOImpl extends HibernateDAO<MchType, Integer> implements MchTypeDAO {

}
