package com.zj198.model;

/**
 * DicBank entity. @author MyEclipse Persistence Tools
 */

public class DicBank implements java.io.Serializable {

	private static final long serialVersionUID = 625769477632354960L;
	private Integer id;
	private String name;
	private String fullname;
	private String code;
	private String website;
	private String logo;

	/** default constructor */
	public DicBank() {
	}

	// Property accessors
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFullname() {
		return this.fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getWebsite() {
		return this.website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getLogo() {
		return this.logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

}