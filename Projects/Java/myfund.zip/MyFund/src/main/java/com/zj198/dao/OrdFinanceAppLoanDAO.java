package com.zj198.dao;

import com.zj198.model.OrdFinanceAppLoan;

/**
 * @author 岳龙
 * Description:
 * CreateAuthor:岳龙
 * CreateDate:2012-7-17 15:47:30
 */
public interface OrdFinanceAppLoanDAO extends BaseDAO<OrdFinanceAppLoan, Integer>{

}
