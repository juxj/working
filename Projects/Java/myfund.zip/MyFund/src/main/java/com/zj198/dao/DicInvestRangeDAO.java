package com.zj198.dao;

import java.util.List;

import com.zj198.model.DicInvestRange;

public interface DicInvestRangeDAO extends BaseDAO<DicInvestRange, Integer> {

	public List<DicInvestRange> findDicInvestRangeListByType(int typeId);
}
