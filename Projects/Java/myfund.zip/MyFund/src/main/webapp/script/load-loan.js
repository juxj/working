$(function(){
	$('#page_loan_sel').css('background','url(/images/nav_hover.png) 0% 0%');
	$('#page_loan_sel a').css('color','#494949');
});