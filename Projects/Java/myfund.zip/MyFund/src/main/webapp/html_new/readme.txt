﻿此目录为前台页面目录

index.html------------------------------首页
reg.html--------------------------------注册页
user_types.html-------------------------用户选择用户类型
user_login.html-------------------------登录页
member_Personal.html--------------------个人用户中心页
member_enterprise.html------------------企业用户中心页
ca.html---------------------------------CA证书关联页
ca_test.html----------------------------CA证书关联成功or失败页
phone_test.html-------------------------手机验证码接受页
old_update_reginfo.html-----------------老版用户登录信息更新提示页

complete_info_Personal.html-------------完善信息（个人）页
complete_info_enterprise.html-----------完善信息（企业）页
complete_info_bank.html-----------------完善信息（银行金融机构）页
complete_info_others.html---------------完善信息（非银行金融机构）页
complete_info_service.html--------------完善信息（服务方）页

edit_info_reg.html----------------------编辑信息（注册）页
edit_info_enterprise.html---------------编辑信息（企业）页
edit_info_bank.html---------------------编辑信息（银行金融机构）页
edit_info_others.html-------------------编辑信息（非银行金融机构）页
edit_info_service.html------------------编辑信息（服务方）页

Financial_ services.html----------------理财产品首页
search.html-----------------------------理财产品列表页面_银行理财
search01.html---------------------------理财产品列表页面_基本理财
search_ xq.html-------------------------理财产品列表详情页面
Enterprise_info_Management.html---------账户管理企业信息管理
Enterprise_info_Management01.html-------账户管理企业信息管理(修改)
financing_Service.jsp-------------------融资服务首页
Financing_S_pages.html------------------融资服务搜索结果页
Financing_services_DP.html--------------融资服务搜索结果页产品详情页

Enterprises_apply.html------------------企业经营贷款快速申请第一步
Enterprises_apply_second.html-----------企业经营贷款快速申请第二步
Enterprises_apply_third.html------------企业经营贷款快速申请第三步
Personal_apply.html---------------------个人消费贷款快速申请第一步
Personal_Operate_apply.html-------------个人经营快速申请第一步
Personal_Purchase_apply.html------------个人购房贷款快速申请第一步

information_centre.html-----------------信息中心首页
Information_list_page.html--------------信息中心新闻列表页面
Information_detailed_page.html----------信息中心新闻详细页面

Catering_f_page.html--------------------融资频道餐饮基金页面
error_page.html-------------------------系统提示错误页面
serviceItemHome.jsp---------------------融资服务信息页面
Service_details_page.html---------------融资服务-服务详情页																	

Financing_dictionary_page.html----------信息中心融资词典详情页面
Financial_encyclopedia_page.html--------信息中心理财百科详情页面
Financial_page.html---------------------信息中心金融黄页详情页面
User_guides_page.html-------------------信息中心用户指南详情页面

f_list_page.html------------------------资金信息列表页面
f_info_detailed_page.html---------------资金信息详细页面
Service_details_page.html---------------服务详情页面
About_us.html---------------------------关于我们页面
reg_info_Management.html----------------用户中心账户管理注册信息管理页面
P_information_management.html-----------用户中心项目信息管理页面
Project_info_public.html----------------发布项目信息页面
capital_info_public.html----------------发布新资金信息(第一步)
capital2_info_public.html---------------发布新资金信息(第二步)
Notice_page.html------------------------用户中心消息与提醒页面
Change_Password.html--------------------用户中心修改密码页面


Financing_int_management.html-----------融资意向管理页面(企业/个人)
Financing_demand_details.html-----------融资需求管理(企业/个人)-需求详情页面
Financing_app_management01.html---------融资申请管理页面(企业/个人)
Financing_app_needs.html----------------融资申请管理(企业/个人)-申请详情页面
Financing_Credit_details.html-----------融资申请管理(企业/个人)-申贷资料详情页
Financing_Loan_management.html----------融资贷后管理页面(企业/个人)
Financing_Loan_details.html-------------融资贷后管理(企业/个人)-贷款详情页
Financing_refund_details.html-----------融资贷后管理(企业/个人)-还款详情页

Financing_pro_management.html-----------融资管理(银行)-融资产品管理页面(同其他金融机构)
Financing_pro_details.html--------------融资管理(银行)-产品详情页面(同其他金融机构)
Financing_dm_management.html------------融资需求管理页面(银行)
Financing_dmand_details01.html----------融资需求管理(银行)-需求详情页面
Financing_app_management.html-----------融资申请管理页面(银行 同 其他金融机构)
Financing_loan_information.html---------融资申请管理(银行)-填写贷款放款信息页面

new_products_publish.html---------------融资管理(其他金融机构)-发布新产品页面
Credit_vipPublicity_page.html-----------资信通vip宣传页
url_error_page.html---------------------旧版网站方位错误提示页
activate.html---------------------------注册页面
url_error_page.html---------------------网站已改版

Fund_infor_database.html----------------融资俱乐部_资金信息库页面
Financing_club.html---------------------融资俱乐部_首页
Pro_introduction.html-------------------推广公司介绍页面
 