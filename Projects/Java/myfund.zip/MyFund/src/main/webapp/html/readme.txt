﻿此目录为前台页面目录

index.html------------------------------首页
reg.html--------------------------------注册页
user_types.html-------------------------用户选择用户类型
user_login.html-------------------------登录页
member_Personal.html--------------------个人用户中心页
member_enterprise.html------------------企业用户中心页
ca.html---------------------------------CA证书关联页
ca_test.html----------------------------CA证书关联成功or失败页
phone_test.html-------------------------手机验证码接受页

complete_info_Personal.html-------------完善信息（个人）页
complete_info_enterprise.html-----------完善信息（企业）页
complete_info_bank.html-----------------完善信息（银行金融机构）页
complete_info_others.html---------------完善信息（非银行金融机构）页
complete_info_service.html--------------完善信息（服务方）页

edit_info_reg.html----------------------编辑信息（注册）页
edit_info_enterprise.html---------------编辑信息（企业）页
edit_info_bank.html---------------------编辑信息（银行金融机构）页
edit_info_others.html-------------------编辑信息（非银行金融机构）页
edit_info_service.html------------------编辑信息（服务方）页