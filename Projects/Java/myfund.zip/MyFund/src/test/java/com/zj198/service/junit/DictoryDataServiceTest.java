package com.zj198.service.junit;


import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.zj198.service.common.DictoryDataService;

/**
 * 测试公共方法(字典表的name替换bean的id值)
 * 
 * @author zeroleavebaoyang@gmail.com
 * @since 2012-7-4|下午2:25:09
 */
public class DictoryDataServiceTest {

    private ApplicationContext ac = null;

    @Before
    public void before() {
      //  ac = new ClassPathXmlApplicationContext(new String[] { "applicationContext.xml", "applicationContext-dao.xml",
      //          "applicationContext-service.xml" });
    }

    @Test
    public void test() {
    	/*
        DictoryDataService dictoryDataService = (DictoryDataService) ac.getBean("dictoryDataService");
        System.out.println(dictoryDataService.setNameRepaceId(143));
        System.out.println(dictoryDataService.setNameRepaceId(",6,2,1,123,"));
        */
    }

}
